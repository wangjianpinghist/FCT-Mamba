# FACT-Mamba

A compact PyTorch implementation of the main FACT-Mamba network for four-class task-based EEG classification: TDC, ADHD, TS, and TS+ADHD.

## Components

- **CA-MSG:** Condition-dependent fusion of theta, alpha, and beta channel correlations, positive/negative graph decomposition, a regional prior, and signed graph propagation.
- **HBM:** Regional within-trial bidirectional selective Mamba, followed by cross-trial bidirectional selective Mamba.
- **RG:** EEG-derived trial reliability, detached reliability context, and reliability-modulated trial pooling.
- **FCD:** Separate TS and ADHD factor scores with comorbidity interaction and bounded residual corrections.

## Configuration

| Parameter | Value |
| --- | --- |
| EEG channels / samples / sampling rate | 32 / 160 / 128 Hz |
| Feature dimension | 80 |
| Signed graph layers | 4 |
| Neighbors per graph node | 8 |
| Mamba state dimension | 32 |
| Mamba expansion factor | 2 |
| Mamba convolution width | 4 |
| Dropout | 0.20 |
| Local sequence length / stride | 12 / 6 |
| Cross-trial bidirectional Mamba layers | 2 |
| Classification classes | TDC, ADHD, TS, TS+ADHD |

The experimental configuration uses AdamW, a learning rate of `4e-4`, weight decay of `1.5e-4`, batch size `16`, a maximum of `150` epochs, early stopping patience `25`, gradient clipping norm `4.0`, `ReduceLROnPlateau`, mixed precision, and stratified five-fold subject-independent evaluation.

## Input and output

The forward pass accepts four tensors:

- `eeg`: `[batch, 12, 32, 160]`, subject-wise channel-standardized EEG epochs.
- `trial_type`: `[batch, 12]` with Go = 0, NoGo = 1, Conflict = 2.
- `session`: `[batch, 12]` with session indices 0–1.
- `block`: `[batch, 12]` with block indices 0–5.

The channel order is `Fp1, Fp2, AF3, AF4, F7, F3, Fz, F4, F8, FC5, FC1, FC2, FC6, T7, C3, Cz, C4, T8, CP5, CP1, CP2, CP6, P7, P3, Pz, P4, P8, PO7, PO3, PO4, PO8, Oz`.

```python
from fact_mamba import FACTMamba

model = FACTMamba()
outputs = model(eeg, trial_type, session, block)
sequence_logits = outputs["logits"]
```

Each subject's 72 trials are organized as two 36-trial sessions. Windows of 12 consecutive trials with stride 6 are formed independently within each session, producing 10 sequences per subject. Subject-level class probabilities are computed by averaging sequence logits and then applying softmax. The `session_window_starts` and `aggregate_subject_probabilities` helpers support this aggregation.

The network returns sequence-level four-class logits, TS/ADHD factor logits, a comorbidity interaction logit, and trial reliability logits. Reliability targets and auxiliary losses are part of the experiment procedure and are not included here.

## Requirements

Python 3.10+ and PyTorch 2.2+.

This release contains the network definition only. It does not include patient data, pretrained weights, experiment management, or plotting scripts. Meaningful predictions require trained parameters.
