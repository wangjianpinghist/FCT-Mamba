from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import Tensor, nn
import torch.nn.functional as F


@dataclass(frozen=True)
class ModelConfig:
    channels: int = 32
    time_points: int = 160
    sampling_rate: int = 128
    conditions: int = 3
    sessions: int = 2
    blocks: int = 6
    feature_dim: int = 80
    graph_layers: int = 4
    graph_neighbors: int = 8
    mamba_state_dim: int = 32
    mamba_expand: int = 2
    mamba_conv_width: int = 4
    dropout: float = 0.20
    sequence_length: int = 12
    sequence_stride: int = 6
    intra_trial_layers: int = 1
    inter_trial_layers: int = 2


SCALP_REGION = (
    0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 3, 4, 4,
    4, 3, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7,
)
BANDS = ((4.0, 8.0), (8.0, 13.0), (13.0, 30.0))


class AttentionPool(nn.Module):
    def __init__(self, width: int):
        super().__init__()
        self.score = nn.Sequential(
            nn.LayerNorm(width), nn.Linear(width, width // 2),
            nn.Tanh(), nn.Linear(width // 2, 1),
        )

    def forward(self, x: Tensor, reliability: Tensor | None = None) -> Tensor:
        scores = self.score(x).squeeze(-1)
        if reliability is not None:
            scores = scores + torch.log(reliability.clamp(0.08, 1.0))
        weights = torch.softmax(scores, dim=1)
        return (x * weights.unsqueeze(-1)).sum(dim=1)


class SelectiveMamba(nn.Module):
    def __init__(self, width: int, state_dim: int, conv_width: int, expand: int):
        super().__init__()
        inner = width * expand
        rank = math.ceil(width / 16)
        self.inner = inner
        self.state_dim = state_dim
        self.in_proj = nn.Linear(width, 2 * inner, bias=False)
        self.conv = nn.Conv1d(
            inner, inner, conv_width, groups=inner, padding=conv_width - 1
        )
        self.param_proj = nn.Linear(inner, rank + 2 * state_dim, bias=False)
        self.dt_proj = nn.Linear(rank, inner)
        self.out_proj = nn.Linear(inner, width, bias=False)
        self.A_log = nn.Parameter(
            torch.log(torch.arange(1, state_dim + 1).float()).repeat(inner, 1)
        )
        self.D = nn.Parameter(torch.ones(inner))

        std = rank ** -0.5
        nn.init.uniform_(self.dt_proj.weight, -std, std)
        dt = torch.exp(
            torch.rand(inner) * (math.log(0.1) - math.log(0.001))
            + math.log(0.001)
        )
        with torch.no_grad():
            self.dt_proj.bias.copy_(dt + torch.log(-torch.expm1(-dt)))

    def forward(self, sequence: Tensor) -> Tensor:
        length = sequence.shape[1]
        x, z = self.in_proj(sequence).chunk(2, dim=-1)
        x = F.silu(self.conv(x.transpose(1, 2))[..., :length]).transpose(1, 2)
        dt_rank, B, C = torch.split(
            self.param_proj(x), [self.dt_proj.in_features, self.state_dim, self.state_dim],
            dim=-1,
        )
        delta = F.softplus(self.dt_proj(dt_rank))

        # The state recurrence uses float32 for numerical stability.
        dtype = x.dtype
        x, z, delta, B, C = (t.float() for t in (x, z, delta, B, C))
        A = -torch.exp(self.A_log.float())
        D = self.D.float()
        state = torch.zeros(x.shape[0], self.inner, self.state_dim, device=x.device)
        outputs = []
        for t in range(length):
            dt_t = delta[:, t]
            state = (
                state * torch.exp(dt_t.unsqueeze(-1) * A)
                + x[:, t].unsqueeze(-1) * dt_t.unsqueeze(-1) * B[:, t].unsqueeze(1)
            )
            y = torch.einsum('bin,bn->bi', state, C[:, t]) + D * x[:, t]
            outputs.append(y * F.silu(z[:, t]))
        return self.out_proj(torch.stack(outputs, dim=1).to(dtype))


class BidirectionalMamba(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        width = config.feature_dim
        arguments = (width, config.mamba_state_dim, config.mamba_conv_width,
                     config.mamba_expand)
        self.norm = nn.LayerNorm(width)
        self.forward_core = SelectiveMamba(*arguments)
        self.backward_core = SelectiveMamba(*arguments)
        self.fusion = nn.Linear(2 * width, width, bias=False)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x: Tensor) -> Tensor:
        normalized = self.norm(x)
        left = self.forward_core(normalized)
        right = torch.flip(
            self.backward_core(torch.flip(normalized, dims=(1,))), dims=(1,)
        )
        return x + self.dropout(self.fusion(torch.cat((left, right), dim=-1)))


class ConditionAwareSignedGraph(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.sampling_rate = config.sampling_rate
        self.neighbors = config.graph_neighbors
        self.condition_embedding = nn.Embedding(config.conditions, 16)
        self.band_gate = nn.Sequential(
            nn.Linear(22, 24), nn.GELU(), nn.Dropout(config.dropout / 2),
            nn.Linear(24, 3),
        )
        self.prior_gate = nn.Sequential(
            nn.Linear(19, 16), nn.GELU(), nn.Linear(16, 1), nn.Sigmoid()
        )
        region = torch.tensor(SCALP_REGION)
        distances = (region[:, None] - region[None, :]).abs().float()
        prior = torch.exp(-0.75 * distances)
        prior.fill_diagonal_(0)
        weights, indices = prior.topk(self.neighbors, dim=-1)
        prior = torch.zeros_like(prior).scatter(-1, indices, weights)
        self.register_buffer('regional_prior', prior / prior.sum(-1, keepdim=True).clamp_min(1e-6))

    @staticmethod
    def _correlation(x: Tensor) -> Tensor:
        x = x - x.mean(-1, keepdim=True)
        x = x / x.norm(dim=-1, keepdim=True).clamp_min(1e-5)
        return torch.bmm(x, x.transpose(1, 2))

    def forward(self, eeg: Tensor, condition: Tensor) -> tuple[Tensor, Tensor]:
        eeg = eeg.float()
        frequencies = torch.fft.rfftfreq(
            eeg.shape[-1], d=1.0 / self.sampling_rate
        ).to(eeg.device)
        spectrum = torch.fft.rfft(eeg, dim=-1)
        signals = [
            torch.fft.irfft(
                spectrum * ((frequencies >= lo) & (frequencies < hi)),
                n=eeg.shape[-1], dim=-1,
            )
            for lo, hi in BANDS
        ]
        correlations = torch.stack([self._correlation(s) for s in signals], dim=1)
        power = torch.stack(
            [torch.log1p(s.square().mean(dim=(1, 2))) for s in signals], dim=-1
        )
        strength = correlations.abs().mean(dim=(-1, -2))
        context = self.condition_embedding(condition)
        band_weight = torch.softmax(
            self.band_gate(torch.cat((context, power, strength), dim=-1)), dim=-1
        )
        adjacency = (band_weight[:, :, None, None] * correlations).sum(dim=1)
        diagonal = torch.eye(adjacency.shape[-1], device=adjacency.device, dtype=torch.bool)
        adjacency = adjacency.masked_fill(diagonal.unsqueeze(0), 0.0)

        positive = adjacency.clamp_min(0)
        negative = (-adjacency).clamp_min(0)
        prior_weight = 0.12 + 0.38 * self.prior_gate(torch.cat((context, power), dim=-1))
        positive = positive + prior_weight.unsqueeze(-1) * self.regional_prior

        def sparse_normalize(edges: Tensor) -> Tensor:
            values, indices = edges.topk(self.neighbors, dim=-1)
            sparse = torch.zeros_like(edges).scatter(-1, indices, values)
            return sparse / sparse.sum(dim=-1, keepdim=True).clamp_min(1e-5)

        return sparse_normalize(positive), sparse_normalize(negative)


class SignedGraphLayer(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        width = config.feature_dim
        self.self_projection = nn.Linear(width, width)
        self.positive_projection = nn.Linear(width, width, bias=False)
        self.negative_projection = nn.Linear(width, width, bias=False)
        self.gate = nn.Sequential(
            nn.Linear(width * 3, width), nn.GELU(),
            nn.Linear(width, width), nn.Sigmoid(),
        )
        self.norm = nn.LayerNorm(width)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, nodes: Tensor, positive: Tensor, negative: Tensor) -> Tensor:
        base = self.self_projection(nodes)
        pos = self.positive_projection(torch.bmm(positive, nodes))
        neg = self.negative_projection(torch.bmm(negative, nodes))
        gate = self.gate(torch.cat((base, pos, neg), dim=-1))
        return self.norm(nodes + self.dropout(F.gelu(base + gate * pos - (1 - gate) * neg)))


class TrialEncoder(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.sampling_rate = config.sampling_rate
        self.register_buffer('region', torch.tensor(SCALP_REGION), persistent=False)
        self.waveform_branches = nn.ModuleList([
            nn.Sequential(
                nn.Conv1d(1, 8, kernel_size=k, padding=k // 2, bias=False),
                nn.BatchNorm1d(8), nn.GELU(),
            )
            for k in (7, 15, 31)
        ])
        width = config.feature_dim
        self.node_projection = nn.Sequential(
            nn.Linear(28, width), nn.LayerNorm(width), nn.GELU()
        )
        self.graph_builder = ConditionAwareSignedGraph(config)
        self.graph_layers = nn.ModuleList([
            SignedGraphLayer(config) for _ in range(config.graph_layers)
        ])
        self.graph_pool = AttentionPool(width)
        self.region_conv = nn.Sequential(
            nn.Conv1d(8, width, kernel_size=9, stride=4, padding=4, bias=False),
            nn.BatchNorm1d(width), nn.GELU(),
        )
        self.within_trial = nn.Sequential(*[
            BidirectionalMamba(config) for _ in range(config.intra_trial_layers)
        ])
        self.temporal_pool = AttentionPool(width)
        self.fuse = nn.Sequential(
            nn.Linear(width * 2, width), nn.LayerNorm(width),
            nn.GELU(), nn.Dropout(config.dropout),
        )
        self.reliability_head = nn.Sequential(
            nn.Linear(width * 2 + 3, width // 2), nn.GELU(),
            nn.Dropout(config.dropout), nn.Linear(width // 2, 1),
        )

    def _spectral_features(self, x: Tensor) -> Tensor:
        spectrum = torch.fft.rfft(x.float(), dim=-1)
        power = spectrum.abs().square()
        freq = torch.fft.rfftfreq(x.shape[-1], 1 / self.sampling_rate).to(x.device)
        features = [
            torch.log1p(power[..., (freq >= lo) & (freq < hi)].mean(dim=-1))
            for lo, hi in BANDS
        ]
        theta_phase = torch.angle(spectrum[..., (freq - 6).abs().argmin()])
        beta_amplitude = power[..., (freq >= 18) & (freq < 26)].mean(dim=-1).sqrt()
        features.append(torch.sin(theta_phase) * torch.log1p(beta_amplitude))
        return torch.stack(features, dim=-1)

    def forward(self, eeg: Tensor, condition: Tensor) -> tuple[Tensor, Tensor]:
        count, channels, time = eeg.shape
        signal = eeg.reshape(count * channels, 1, time)
        waveform = torch.cat(
            [branch(signal).mean(dim=-1) for branch in self.waveform_branches], dim=-1
        ).reshape(count, channels, -1)
        nodes = self.node_projection(
            torch.cat((waveform, self._spectral_features(eeg)), dim=-1)
        )
        positive, negative = self.graph_builder(eeg, condition)
        for layer in self.graph_layers:
            nodes = layer(nodes, positive, negative)
        graph_feature = self.graph_pool(nodes)

        regions = torch.stack([
            eeg[:, self.region == region].mean(dim=1) for region in range(8)
        ], dim=1)
        tokens = self.within_trial(self.region_conv(regions).transpose(1, 2))
        temporal_feature = self.temporal_pool(tokens)
        merged = torch.cat((graph_feature, temporal_feature), dim=-1)
        feature = self.fuse(merged)
        stats = torch.stack((
            eeg.std(dim=(1, 2)),
            eeg.diff(dim=-1).abs().mean(dim=(1, 2)),
            (eeg.abs() > 3.5).float().mean(dim=(1, 2)),
        ), dim=-1)
        reliability_logit = self.reliability_head(
            torch.cat((merged, stats), dim=-1)
        ).squeeze(-1)
        return feature, reliability_logit


class FactorizedComorbidityDecoder(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        width = config.feature_dim
        self.ts_head = nn.Linear(width, 1)
        self.adhd_head = nn.Linear(width, 1)
        self.interaction_head = nn.Sequential(
            nn.LayerNorm(width), nn.Linear(width, width // 2),
            nn.GELU(), nn.Dropout(config.dropout), nn.Linear(width // 2, 1),
        )
        self.residual_head = nn.Linear(width, 4)
        nn.init.zeros_(self.residual_head.weight)
        nn.init.zeros_(self.residual_head.bias)

    def forward(self, x: Tensor) -> dict[str, Tensor]:
        ts = self.ts_head(x).squeeze(-1)
        adhd = self.adhd_head(x).squeeze(-1)
        base = torch.stack((
            F.logsigmoid(-ts) + F.logsigmoid(-adhd),
            F.logsigmoid(-ts) + F.logsigmoid(adhd),
            F.logsigmoid(ts) + F.logsigmoid(-adhd),
            F.logsigmoid(ts) + F.logsigmoid(adhd),
        ), dim=-1)
        interaction_logit = self.interaction_head(x).squeeze(-1)
        interaction = torch.tanh(interaction_logit)
        direction = base.new_tensor((-0.25, -0.35, -0.35, 0.95))
        correction = 0.42 * interaction.unsqueeze(-1) * direction
        residual = 0.12 * torch.tanh(self.residual_head(x))
        return {
            'logits': base + correction + residual,
            'ts_logit': ts,
            'adhd_logit': adhd,
            'interaction_logit': interaction_logit,
        }


class FACTMamba(nn.Module):
    def __init__(self, config: ModelConfig = ModelConfig()):
        super().__init__()
        self.config = config
        width = config.feature_dim
        self.trial_encoder = TrialEncoder(config)
        self.condition_embedding = nn.Embedding(config.conditions, width)
        self.session_embedding = nn.Embedding(config.sessions, width)
        self.block_embedding = nn.Embedding(config.blocks, width)
        self.transition_embedding = nn.Embedding(config.conditions ** 2, width)
        self.position_embedding = nn.Parameter(torch.zeros(1, config.sequence_length, width))
        nn.init.normal_(self.position_embedding, std=0.02)
        self.reliability_embedding = nn.Linear(1, width)
        self.across_trials = nn.Sequential(*[
            BidirectionalMamba(config) for _ in range(config.inter_trial_layers)
        ])
        self.trial_pool = AttentionPool(width)
        self.decoder = FactorizedComorbidityDecoder(config)

    def forward(
        self, eeg: Tensor, trial_type: Tensor, session: Tensor, block: Tensor
    ) -> dict[str, Tensor]:
        if eeg.ndim != 4 or eeg.shape[2:] != (self.config.channels, self.config.time_points):
            raise ValueError('eeg must have shape [batch, sequence, 32, 160]')
        batch, length, channels, time = eeg.shape
        if length != self.config.sequence_length:
            raise ValueError(f'sequence length must be {self.config.sequence_length}')
        for name, labels in [('trial_type', trial_type), ('session', session), ('block', block)]:
            if labels.shape != (batch, length):
                raise ValueError(f'{name} must have shape [batch, sequence]')

        feature, quality_logit = self.trial_encoder(
            eeg.reshape(batch * length, channels, time), trial_type.reshape(-1)
        )
        feature = feature.reshape(batch, length, -1)
        quality_logit = quality_logit.reshape(batch, length)
        reliability = torch.sigmoid(quality_logit)
        previous = torch.cat((trial_type[:, :1], trial_type[:, :-1]), dim=1)
        transition = previous * self.config.conditions + trial_type
        feature = (
            feature + self.condition_embedding(trial_type)
            + self.session_embedding(session) + self.block_embedding(block)
            + self.transition_embedding(transition)
            + self.position_embedding[:, :length]
            + self.reliability_embedding((reliability.detach() - 0.5).unsqueeze(-1))
        )
        feature = self.across_trials(feature)
        sequence_feature = self.trial_pool(feature, reliability.detach())
        result = self.decoder(sequence_feature)
        result['reliability_logit'] = quality_logit
        return result


def session_window_starts(
    sessions: int = 2, trials_per_session: int = 36,
    length: int = 12, stride: int = 6,
) -> list[int]:
    return [
        session * trials_per_session + offset
        for session in range(sessions)
        for offset in range(0, trials_per_session - length + 1, stride)
    ]


def aggregate_subject_probabilities(sequence_logits: Tensor) -> Tensor:
    """Average sequence logits, then apply softmax for a subject prediction."""
    if sequence_logits.ndim != 2 or sequence_logits.shape[-1] != 4:
        raise ValueError('sequence_logits must have shape [sequences, 4]')
    return sequence_logits.mean(dim=0).softmax(dim=-1)
